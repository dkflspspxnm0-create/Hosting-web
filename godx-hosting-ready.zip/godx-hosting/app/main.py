import os, secrets, shutil, zipfile
from pathlib import Path
from datetime import datetime, timedelta, timezone
from fastapi import FastAPI, Request, Form, UploadFile, File, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from passlib.context import CryptContext
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from sqlalchemy.orm import Session
from .db import Base, engine, SessionLocal
from .models import User, Project, ProjectEnv, Activity
from .settings import settings

BASE = Path(__file__).resolve().parent.parent
UPLOADS = BASE / "uploads"
BACKUPS = BASE / "backups"
UPLOADS.mkdir(exist_ok=True); BACKUPS.mkdir(exist_ok=True); (BASE/"data").mkdir(exist_ok=True)
Base.metadata.create_all(bind=engine)
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
signer = URLSafeTimedSerializer(settings.SECRET_KEY)
app = FastAPI(title=settings.APP_NAME)
app.mount("/static", StaticFiles(directory=str(BASE/"app/static")), name="static")
templates = Jinja2Templates(directory=str(BASE/"app/templates"))

def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()

def token(user_id): return signer.dumps({"uid": user_id})
def current_user(request: Request, s: Session):
    raw=request.cookies.get("godx_session")
    if not raw: return None
    try: data=signer.loads(raw, max_age=60*60*24*7)
    except (BadSignature, SignatureExpired): return None
    return s.get(User, data.get("uid"))

def require_user(request,s):
    u=current_user(request,s)
    if not u or u.is_banned: raise HTTPException(401)
    return u

def log(s, actor, action): s.add(Activity(actor=actor, action=action)); s.commit()

def render(request, name, **ctx):
    return templates.TemplateResponse(name, {"request":request, "settings":settings, **ctx})

@app.on_event("startup")
def seed():
    s=SessionLocal()
    try:
        u=s.query(User).filter(User.username==settings.ADMIN_USERNAME).first()
        if not u and settings.ADMIN_PASSWORD != "CHANGE_ME":
            u=User(username=settings.ADMIN_USERNAME,email=settings.ADMIN_EMAIL,password_hash=pwd.hash(settings.ADMIN_PASSWORD),is_admin=True)
            s.add(u); s.commit()
    finally: s.close()

@app.get("/health")
def health(): return {"ok":True,"service":"godx-hosting"}

@app.get("/", response_class=HTMLResponse)
def home(request: Request, s: Session=Depends(db)):
    u=current_user(request,s)
    return render(request,"home.html",user=u)

@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request): return render(request,"register.html")
@app.post("/register")
def register(request: Request, username: str=Form(...), email: str=Form(...), password: str=Form(...), s: Session=Depends(db)):
    username=username.strip(); email=email.strip().lower()
    if len(password)<8: return render(request,"register.html",error="Password must be at least 8 characters.")
    if s.query(User).filter((User.username==username)|(User.email==email)).first(): return render(request,"register.html",error="Username or email already exists.")
    u=User(username=username,email=email,password_hash=pwd.hash(password)); s.add(u); s.commit();
    r=RedirectResponse("/dashboard",303); r.set_cookie("godx_session",token(u.id),httponly=True,samesite="lax",secure=False,max_age=604800); return r

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request): return render(request,"login.html")
@app.post("/login")
def login(request: Request, email: str=Form(...), password: str=Form(...), s: Session=Depends(db)):
    u=s.query(User).filter(User.email==email.strip().lower()).first()
    if not u or u.is_banned or not pwd.verify(password,u.password_hash): return render(request,"login.html",error="Invalid login details.")
    r=RedirectResponse("/admin" if u.is_admin else "/dashboard",303); r.set_cookie("godx_session",token(u.id),httponly=True,samesite="lax",secure=False,max_age=604800); return r

@app.get("/logout")
def logout():
    r=RedirectResponse("/",303); r.delete_cookie("godx_session"); return r

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, s: Session=Depends(db)):
    u=require_user(request,s); projects=s.query(Project).filter(Project.owner_id==u.id).order_by(Project.id.desc()).all()
    return render(request,"dashboard.html",user=u,projects=projects)

@app.post("/projects")
def create_project(request: Request, name: str=Form(...), runtime: str=Form(...), start_command: str=Form(""), s: Session=Depends(db)):
    u=require_user(request,s)
    if len(u.projects)>=settings.FREE_PROJECTS: return RedirectResponse("/dashboard?error=project_limit",303)
    slug=''.join(c.lower() if c.isalnum() else '-' for c in name).strip('-')[:45] or 'project'
    slug=f"{slug}-{secrets.token_hex(3)}"
    p=Project(owner_id=u.id,name=name.strip(),runtime=runtime,start_command=start_command,subdomain=slug,ram_mb=settings.FREE_RAM_MB,storage_mb=settings.FREE_STORAGE_MB,cpu=settings.FREE_CPU)
    s.add(p); s.commit(); log(s,u.username,f"Created project {p.name}")
    return RedirectResponse(f"/projects/{p.id}",303)

@app.get("/projects/{pid}", response_class=HTMLResponse)
def project_page(pid:int,request:Request,s:Session=Depends(db)):
    u=require_user(request,s); p=s.get(Project,pid)
    if not p or p.owner_id!=u.id: raise HTTPException(404)
    return render(request,"project.html",user=u,project=p)

@app.post("/projects/{pid}/upload")
def upload(pid:int,request:Request,file:UploadFile=File(...),s:Session=Depends(db)):
    u=require_user(request,s); p=s.get(Project,pid)
    if not p or p.owner_id!=u.id: raise HTTPException(404)
    limit=settings.MAX_ZIP_MB*1024*1024 if (file.filename or '').lower().endswith('.zip') else settings.MAX_UPLOAD_MB*1024*1024
    dest=UPLOADS/f"{p.id}"
    dest.mkdir(parents=True,exist_ok=True)
    out=dest/(Path(file.filename or 'upload.bin').name)
    size=0
    with out.open('wb') as f:
        while chunk:=await file.read(1024*1024):
            size+=len(chunk)
            if size>limit: out.unlink(missing_ok=True); return RedirectResponse(f"/projects/{pid}?error=upload_limit",303)
            f.write(chunk)
    log(s,u.username,f"Uploaded {out.name} to {p.name}")
    return RedirectResponse(f"/projects/{pid}?uploaded=1",303)

@app.post("/projects/{pid}/status/{action}")
def project_status(pid:int,action:str,request:Request,s:Session=Depends(db)):
    u=require_user(request,s); p=s.get(Project,pid)
    if not p or p.owner_id!=u.id or action not in {'start','stop','restart'}: raise HTTPException(404)
    p.status='running' if action in {'start','restart'} else 'stopped'; s.commit(); log(s,u.username,f"{action.title()} requested for {p.name}")
    return RedirectResponse(f"/projects/{pid}",303)

@app.post("/projects/{pid}/env")
def add_env(pid:int,request:Request,key:str=Form(...),value:str=Form(...),s:Session=Depends(db)):
    u=require_user(request,s); p=s.get(Project,pid)
    if not p or p.owner_id!=u.id: raise HTTPException(404)
    s.add(ProjectEnv(project_id=p.id,key=key.strip(),value=value)); s.commit(); return RedirectResponse(f"/projects/{pid}",303)

@app.post("/projects/{pid}/delete")
def delete_project(pid:int,request:Request,s:Session=Depends(db)):
    u=require_user(request,s); p=s.get(Project,pid)
    if not p or p.owner_id!=u.id: raise HTTPException(404)
    shutil.rmtree(UPLOADS/f"{p.id}",ignore_errors=True); s.delete(p); s.commit(); log(s,u.username,f"Deleted project {p.name}"); return RedirectResponse('/dashboard',303)

@app.get("/admin", response_class=HTMLResponse)
def admin(request:Request,s:Session=Depends(db)):
    u=require_user(request,s)
    if not u.is_admin: raise HTTPException(403)
    return render(request,"admin.html",user=u,users=s.query(User).order_by(User.id.desc()).all(),projects=s.query(Project).order_by(Project.id.desc()).all(),activities=s.query(Activity).order_by(Activity.id.desc()).limit(30).all())

@app.post("/admin/users/{uid}/toggle")
def toggle_user(uid:int,request:Request,s:Session=Depends(db)):
    a=require_user(request,s)
    if not a.is_admin: raise HTTPException(403)
    u=s.get(User,uid)
    if u and not u.is_admin: u.is_banned=not u.is_banned; s.commit(); log(s,a.username, f"{'Banned' if u.is_banned else 'Unbanned'} user {u.username}")
    return RedirectResponse('/admin',303)

@app.post("/admin/maintenance")
def maintenance(request:Request,s:Session=Depends(db)):
    u=require_user(request,s)
    if not u.is_admin: raise HTTPException(403)
    settings.MAINTENANCE_MODE=not settings.MAINTENANCE_MODE
    log(s,u.username,f"Maintenance mode {'enabled' if settings.MAINTENANCE_MODE else 'disabled'}")
    return RedirectResponse('/admin',303)
