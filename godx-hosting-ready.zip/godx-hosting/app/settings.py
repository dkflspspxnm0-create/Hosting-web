from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    APP_NAME: str = "GodX Hosting"
    SECRET_KEY: str = "CHANGE_ME"
    DATABASE_URL: str = "sqlite:///./data/godx.db"
    ADMIN_USERNAME: str = "godx_raftaar21"
    ADMIN_EMAIL: str = "change-me@example.com"
    ADMIN_PASSWORD: str = "CHANGE_ME"
    MAX_UPLOAD_MB: int = 500
    MAX_ZIP_MB: int = 500
    FREE_PROJECTS: int = 2
    FREE_RAM_MB: int = 512
    FREE_STORAGE_MB: int = 2048
    FREE_CPU: float = 0.5
    BASE_DOMAIN: str = "godx-hosting.pages.dev"
    MAINTENANCE_MODE: bool = False
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
