from datetime import datetime, timezone
from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship
from .db import Base

def now(): return datetime.now(timezone.utc)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String(80), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    is_admin = Column(Boolean, default=False)
    is_banned = Column(Boolean, default=False)
    created_at = Column(DateTime, default=now)
    projects = relationship("Project", back_populates="owner", cascade="all, delete-orphan")

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(120), nullable=False)
    runtime = Column(String(40), default="python")
    start_command = Column(String(255), default="")
    status = Column(String(30), default="stopped")
    subdomain = Column(String(120), unique=True, nullable=True)
    ram_mb = Column(Integer, default=512)
    storage_mb = Column(Integer, default=2048)
    cpu = Column(Float, default=0.5)
    expires_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=now)
    owner = relationship("User", back_populates="projects")
    envs = relationship("ProjectEnv", back_populates="project", cascade="all, delete-orphan")

class ProjectEnv(Base):
    __tablename__ = "project_envs"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    key = Column(String(120), nullable=False)
    value = Column(Text, nullable=False)
    project = relationship("Project", back_populates="envs")

class Activity(Base):
    __tablename__ = "activities"
    id = Column(Integer, primary_key=True)
    actor = Column(String(120), nullable=False)
    action = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=now)
