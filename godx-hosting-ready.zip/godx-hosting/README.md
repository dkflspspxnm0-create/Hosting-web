# GodX Hosting

Production-oriented hosting control panel starter for Railway-first deployment and later VPS migration.

## Included
- Dark + blue-shine dashboard
- Email/password registration and login
- Admin panel
- Project creation, rename, delete
- ZIP/file upload with configurable limits
- Runtime selector: Python, Node.js, Java, PHP, Static
- Custom start command field
- Environment variables UI
- Project status/log UI foundation
- Hosting expiry notifications foundation
- Backup buttons/foundation
- Maintenance mode
- Admin activity log
- Configurable free plan limits
- Dockerfile + docker-compose for VPS migration
- Railway Docker deployment config

## Important
This release intentionally does NOT execute arbitrary uploaded code inside the web process. Actual multi-tenant code execution should be handled by a separate isolated runner (Docker/container service) on the VPS. The panel is structured so a runner API can be attached later without rebuilding the UI.

## Local / VPS
1. Copy `.env.example` to `.env`.
2. Set a strong `SECRET_KEY` and new admin password.
3. Run `docker compose up -d --build`.
4. Open `http://SERVER_IP:8000`.

## Railway
Create a GitHub repo from this folder and deploy it as a Docker service. Add the environment variables from `.env.example` in Railway Variables. For persistent production data, use a persistent volume or external PostgreSQL/object storage.
